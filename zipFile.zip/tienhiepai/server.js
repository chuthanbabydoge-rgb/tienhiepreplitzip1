const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 9000;

// Serve static files from the current directory
app.use(express.static(path.join(__dirname)));

// Serve the main HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'tienhiepv3.html'));
});

// Example API route for future use
app.get('/api/status', (req, res) => {
    res.json({ status: 'success', message: 'Backend is running' });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
